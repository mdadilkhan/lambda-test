export const headers = {
    'Access-Control-Allow-Headers': 'Authorization',
    'Access-Control-Allow-Origin' : 'process.env.ALLOWED_ORIFIN_FOR_CORS',
    'Access-Control-Allow-Methods':'DELETE,GET,POST,OPTIONS,PUT,PATCH'
}